const { MessageEmbed } = require('discord.js')
const ms = require('ms');
module.exports = {
        name: "end",
        description: "kết thúc give",
        accessableby: "Administrator",
        category: "giveaway",
        aliases: ["giveaway-end"],
        usage: 'end sài id tin nhắn give',
    run: async (bot, message, args) => {
      if(!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")){
        return message.channel.send(':x: Bạn cần có quyền quản lý tin nhắn để quản lý give.');
    }

    // If no message ID or giveaway name is specified
    if(!args[0]){
        return message.channel.send(':x: Bạn phải chỉ định một ID tin nhắn hợp lệ!');
    }

    // try to found the giveaway with prize then with ID
    let giveaway = 
    // Search with giveaway prize
    bot.giveawaysManager.giveaways.find((g) => g.prize === args.join(' ')) ||
    // Search with giveaway ID
    bot.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

    // If no giveaway was found
    if(!giveaway){
        return message.channel.send('Unable to find a giveaway for `'+ args.join(' ') + '`.');
    }

    // Edit the giveaway
    bot.giveawaysManager.edit(giveaway.messageID, {
        setEndTimestamp: Date.now()
    })
    // Success message
    .then(() => {
        // Success message
        message.channel.send('Giveaway sẽ kết thúc sau '+(bot.giveawaysManager.options.updateCountdownEvery/1000)+' giây...');
    })
    .catch((e) => {
        if(e.startsWith(`Give với id ${giveaway.messageID} nó đã kết thúc.`)){
            message.channel.send('Nó đã kết thúc!');
        } else {
            console.error(e);
            message.channel.send('Có 1 lỗi');
        }
    });
    }
}