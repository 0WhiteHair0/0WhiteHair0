const { MessageEmbed } = require('discord.js')
const ms = require('ms');
module.exports = {
  name: "reroll",
  description:
    "chọn người win mới",
  usage: "reroll",
  category:"giveaway",
    run: async (bot, message, args) => {
       if(!message.member.hasPermission('MANAGE_MESSAGES') && !message.member.roles.cache.some((r) => r.name === "Giveaways")){
        return message.channel.send(':x: Bạn cần có quyền quản lý tin nhắn để reroll give.');
    }

    // If no message ID or giveaway name is specified
    if(!args[0]){
        return message.channel.send(':x: Bạn phải nêu một ID tin nhắn hợp lệ!');
    }

    // try to found the giveaway with prize then with ID
    let giveaway = 
    // Search with giveaway prize
    bot.giveawaysManager.giveaways.find((g) => g.prize === args.join(' ')) ||
    // Search with giveaway ID
    bot.giveawaysManager.giveaways.find((g) => g.messageID === args[0]);

    // If no giveaway was found
    if(!giveaway){
        return message.channel.send('Không thể tìm thấy Give cho `'+ args.join(' ') +'`.');
    }

    // Reroll the giveaway
    bot.giveawaysManager.reroll(giveaway.messageID)
    .then(() => {
        // Success message
        message.channel.send('Đa chọn lại người win khác!!!');
    })
    .catch((e) => {
        if(e.startsWith(`Give với id ${giveaway.messageID} chưa kết thúc.`)){
            message.channel.send('Give này chưa hết');
        } else {
            console.error(e);
            message.channel.send('Đã có lỗi');
        }
    });

    }
}