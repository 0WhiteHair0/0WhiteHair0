const discord = require("discord.js");

module.exports = {
  name: "invite",
  category: "info",
  description: "INVITE BOT",
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setTitle(`Link invite bot`)
    .setDescription(`<:link:845315257430048788>  [Nhấn Vô](https://discord.com/api/oauth2/authorize?client_id=894429648295960627&permissions=8&scope=bot) hay [Server Của White ](https://discord.gg/39Wgugebmz)`)
    .setColor("RANDOM")
    .setFooter(`làm bởi White `)
    .setTimestamp(message.timestamp = Date.now())
    
    message.channel .send(embed)
    
  
  }
}