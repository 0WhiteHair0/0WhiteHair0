const discord_akairo_1 = require("discord-akairo");
const Discord = require('discord.js')
const db = require("quick.db")
module.exports = {
    name: 'hack',
    category: 'fun',
    
run: async (client, message, args) => {
    
       


       const user = await message.mentions.users.first()
        if(!user) return message.channel.send("hack ak  .")
        

        message.channel.send(`Hack nè @${user.username} Bây giờ...`)
        .then((msg) => {
            setTimeout(function() {
            msg.edit(`[▝]Tìm Ip`);
          }, 1500)
            setTimeout(function() {
            msg.edit(`[▗] **IP Là** : 192.168.9.100:9999`);
          }, 3000)
          setTimeout(function() {
            msg.edit(`[▖] Lấy giữ liệu...`);
          }, 4500)
          setTimeout(function() {
            msg.edit(`[▘] Đang xem acc...`);
          }, 6000)
          setTimeout(function() {
            msg.edit(`[▝] Tìm Email...`);
          }, 7500)
          setTimeout(function() {
            msg.edit(`[▗] **Email** : ${user.username}@quietcity.com`);
          }, 9000)
          setTimeout(function() {
            msg.edit(`[▖] Hack bất kì acc nào...`);
          },  10500)
          setTimeout(function() {
            msg.edit(`[▘]đợi tí...`);
          },  12000)
         setTimeout(function() {
            msg.edit(`Hack xong @${user.username}`);
         }, 13500)
         setTimeout(function() {
            message.channel.send('Có đăng ký chưa hay là bay tất cả acc https://www.youtube.com/channel/UCtQD5dMGhtW3Z67wcIN4a7A')
         }, 15000)
         });

    }
   
}