const Discord = require("discord.js");

const malScraper = require('mal-scraper');


module.exports = {
  name: "anime",
  category: "search",
  description: "Lấy thông tin về một anime",
  usage: "[command | Anime]",
  run: async (client, message, args) => {
    //command
    const search = `${args}`;
    if (!search)
      return message.reply('Please add a search query!');

    malScraper.getInfoFromName(search)
      .then((data) => {
        const malEmbed = new Discord.MessageEmbed()
          .setAuthor(`List anime :) ${args}`.split(',').join(' '))
          .setThumbnail(data.picture)
          .setColor('RANDOM') //What ever u want color!
          .addField('Công chiếu', `\`${data.premiered}\``, true)
          .addField('Phát tin', `\`${data.broadcast}\``, true)
          .addField('Thể loại', `\`${data.genres}\``, true)
          .addField('Tên tiếng anh', `\`${data.englishTitle}\``, true)
          .addField('Tên tiếng nhật', `\`${data.japaneseTitle}\``, true)
          .addField('Kiểu', `\`${data.type}\``, true)
          .addField('Tập', `\`${data.episodes}\``, true)
          .addField('Đánh giá', `\`${data.rating}\``, true)
          .addField('Phát sóng', `\`${data.aired}\``, true)
          .addField('Điểm', `\`${data.score}\``, true)
          .addField('Yêu thích', `\`${data.favorites}\``, true)
          .addField('Xep hạng', `\`${data.ranked}\``, true)
          .addField('Khoảng thời gian', `\`${data.duration}\``, true)
          .addField('Studios', `\`${data.studios}\``, true)
          .addField('Độ phổ biến', `\`${data.popularity}\``, true)
          .addField('Các thành viên', `\`${data.members}\``, true)
          .addField('Số liệu thống kê', `\`${data.scoreStats}\``, true)
          .addField('Nguồn', `\`${data.source}\``, true)
          .addField('Từ đồng nghĩa', `\`${data.synonyms}\``, true)
          .addField('Trạng thái', `\`${data.status}\``, true)
          .addField('Định danh', `\`${data.id}\``, true)
          .addField('Link', data.url, true)
          .setTimestamp()
          .setFooter(`Yêu cầu bởi ${message.member.displayName}`,  message.author.displayAvatarURL({ dynamic: true }))

        message.channel.send(malEmbed);

      })
  }
};

//Made By Alison_