const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'clear', // Optional
    aliases: ['clearqueue', 'clear-queue'], // Optional
    category: 'Music',
    description: 'Delete danh sách đợi', 
    run: async (client, message, args) => {
        const voice_channel = message.member.voice.channel;
        const embed = new MessageEmbed()
        .setColor('#FF5757')
        .setDescription(`Bạn cần trong voice để sài`)
        const embed1 = new MessageEmbed()
        .setColor('#85b0d2')
        .setDescription('Danh sách đợi đã bay màu')
        if (!voice_channel) return message.channel.send(embed);
        let isDone = client.player.clearQueue(message);
        if(isDone)
            message.channel.send(embed1);
    }
}