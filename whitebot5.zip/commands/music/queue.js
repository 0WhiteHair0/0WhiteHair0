
const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'queue', // Optional
    aliases: ['q'], // Optional
    category: 'Music',
    description: 'Cung cấp cho bạn thông tin về bài hát', 
    run: async (client, message, args) => {
            const voice_channel = message.member.voice.channel;
            const embed = new MessageEmbed()
            .setColor('#FF5757')
            .setDescription(`Bạn cần trong voice để sài!`)
            if (!voice_channel) return message.channel.send(embed);
            let queue = client.player.getQueue(message);
            if(queue)
            message.channel.send('Danh sách:\n'+(queue.songs.map((song, i) => {
                return `${i === 0 ? 'Bây giờ chơi' : `#${i+1}`} - ${song.name} | ${song.author}`
            }).join('\n')));
    }
}