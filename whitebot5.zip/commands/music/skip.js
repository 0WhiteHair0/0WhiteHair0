const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'skip', // Optional
    aliases: ['sk'], // Optional
    category: 'Music',
    description: 'Bỏ qua 1 bài hát.', 
        run: async (client, message, args) => {
            const voice_channel = message.member.voice.channel;
            const embed = new MessageEmbed()
            .setColor('#FF5757')
            .setDescription(`Bạn cần trong voice để sài!`)
            if(!client.player.isPlaying(message)) {
			message.channel.send('Không xác định phải đang phát để bỏ qua bản nhạc ');

			return;
		}

		await client.player.skip(message);

		message.channel.send('Đã bỏ qua');
	},
};