const { MessageEmbed } = require("discord.js");

module.exports = {
    name: 'volume', // Optional
    category: 'Music',
    description: 'Chỉnh âm lượng bot trong voice', 
    aliases: ['setvolume'], // Optional
    run: async (client, message, args) => {
            const voice_channel = message.member.voice.channel;
            const embed = new MessageEmbed()
            .setColor('#FF5757')
            .setDescription(`Bạn cần trong voice để sài!`)
            if (!voice_channel) return message.channel.send(embed);
            let isDone = client.player.setVolume(message, parseInt(args[0]));
            const volume = new MessageEmbed()
            .setColor('#85b0d2')
            .setDescription(`Âm lượng đã được chỉnh thành ${args[0]}%!`)
            if(isDone)
            message.channel.send(volume);
    }
}